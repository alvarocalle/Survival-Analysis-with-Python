--
-- Import each of the daily drive stats files for Q3 2016 ONLY
--

.mode csv
.echo on
.import ./2016/2016-07-01.csv drive_stats
.import ./2016/2016-07-02.csv drive_stats
.import ./2016/2016-07-03.csv drive_stats
.import ./2016/2016-07-04.csv drive_stats
.import ./2016/2016-07-05.csv drive_stats
.import ./2016/2016-07-06.csv drive_stats
.import ./2016/2016-07-07.csv drive_stats
.import ./2016/2016-07-08.csv drive_stats
.import ./2016/2016-07-09.csv drive_stats
.import ./2016/2016-07-10.csv drive_stats
.import ./2016/2016-07-11.csv drive_stats
.import ./2016/2016-07-12.csv drive_stats
.import ./2016/2016-07-13.csv drive_stats
.import ./2016/2016-07-14.csv drive_stats
.import ./2016/2016-07-15.csv drive_stats
.import ./2016/2016-07-16.csv drive_stats
.import ./2016/2016-07-17.csv drive_stats
.import ./2016/2016-07-18.csv drive_stats
.import ./2016/2016-07-19.csv drive_stats
.import ./2016/2016-07-20.csv drive_stats
.import ./2016/2016-07-21.csv drive_stats
.import ./2016/2016-07-22.csv drive_stats
.import ./2016/2016-07-23.csv drive_stats
.import ./2016/2016-07-24.csv drive_stats
.import ./2016/2016-07-25.csv drive_stats
.import ./2016/2016-07-26.csv drive_stats
.import ./2016/2016-07-27.csv drive_stats
.import ./2016/2016-07-28.csv drive_stats
.import ./2016/2016-07-29.csv drive_stats
.import ./2016/2016-07-30.csv drive_stats
.import ./2016/2016-07-31.csv drive_stats
.import ./2016/2016-08-01.csv drive_stats
.import ./2016/2016-08-02.csv drive_stats
.import ./2016/2016-08-03.csv drive_stats
.import ./2016/2016-08-04.csv drive_stats
.import ./2016/2016-08-05.csv drive_stats
.import ./2016/2016-08-06.csv drive_stats
.import ./2016/2016-08-07.csv drive_stats
.import ./2016/2016-08-08.csv drive_stats
.import ./2016/2016-08-09.csv drive_stats
.import ./2016/2016-08-10.csv drive_stats
.import ./2016/2016-08-11.csv drive_stats
.import ./2016/2016-08-12.csv drive_stats
.import ./2016/2016-08-13.csv drive_stats
.import ./2016/2016-08-14.csv drive_stats
.import ./2016/2016-08-15.csv drive_stats
.import ./2016/2016-08-16.csv drive_stats
.import ./2016/2016-08-17.csv drive_stats
.import ./2016/2016-08-18.csv drive_stats
.import ./2016/2016-08-19.csv drive_stats
.import ./2016/2016-08-20.csv drive_stats
.import ./2016/2016-08-21.csv drive_stats
.import ./2016/2016-08-22.csv drive_stats
.import ./2016/2016-08-23.csv drive_stats
.import ./2016/2016-08-24.csv drive_stats
.import ./2016/2016-08-25.csv drive_stats
.import ./2016/2016-08-26.csv drive_stats
.import ./2016/2016-08-27.csv drive_stats
.import ./2016/2016-08-28.csv drive_stats
.import ./2016/2016-08-29.csv drive_stats
.import ./2016/2016-08-30.csv drive_stats
.import ./2016/2016-08-31.csv drive_stats
.import ./2016/2016-09-01.csv drive_stats
.import ./2016/2016-09-02.csv drive_stats
.import ./2016/2016-09-03.csv drive_stats
.import ./2016/2016-09-04.csv drive_stats
.import ./2016/2016-09-05.csv drive_stats
.import ./2016/2016-09-06.csv drive_stats
.import ./2016/2016-09-07.csv drive_stats
.import ./2016/2016-09-08.csv drive_stats
.import ./2016/2016-09-09.csv drive_stats
.import ./2016/2016-09-10.csv drive_stats
.import ./2016/2016-09-11.csv drive_stats
.import ./2016/2016-09-12.csv drive_stats
.import ./2016/2016-09-13.csv drive_stats
.import ./2016/2016-09-14.csv drive_stats
.import ./2016/2016-09-15.csv drive_stats
.import ./2016/2016-09-16.csv drive_stats
.import ./2016/2016-09-17.csv drive_stats
.import ./2016/2016-09-18.csv drive_stats
.import ./2016/2016-09-19.csv drive_stats
.import ./2016/2016-09-20.csv drive_stats
.import ./2016/2016-09-21.csv drive_stats
.import ./2016/2016-09-22.csv drive_stats
.import ./2016/2016-09-23.csv drive_stats
.import ./2016/2016-09-24.csv drive_stats
.import ./2016/2016-09-25.csv drive_stats
.import ./2016/2016-09-26.csv drive_stats
.import ./2016/2016-09-27.csv drive_stats
.import ./2016/2016-09-28.csv drive_stats
.import ./2016/2016-09-29.csv drive_stats
.import ./2016/2016-09-30.csv drive_stats

.echo off
.mode list

--
-- The drive stats files each have a header row that labels the
-- columns.  sqlite doesn't understand this when importing from
-- CSV, so they header rows land in the table.  This removes them.
--
delete from drive_stats where model = 'model';
